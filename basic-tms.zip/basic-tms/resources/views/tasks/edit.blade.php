@extends('app')
@section('content')
    <div class="container mt-5">
        <h3 class="mb-5">Task edit
            <a href="{{ route('task')}}" class="btn btn-primary float-right">Back to task</a>
        </h3>

        <form action="{{ route('task.update', ['id' => $task->id] ) }}" method="POST" id="frmEditTask">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="title">Title</label>
                <input type="text" class="form-control" name="title" id="title" placeholder="Enter title" value="{{ $task->title }}">
                @if ($errors->has('title'))
                    <span id="terms-error" class="error invalid-feedback" style="display: inline;">{{ $errors->first('title') }}</span>
                @endif
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea class="form-control" name="description" id="description" rows="10">{{ $task->description }}</textarea>
                @if ($errors->has('description'))
                    <span id="terms-error" class="error invalid-feedback" style="display: inline;">{{ $errors->first('description') }}</span>
                @endif
            </div>

            <div class="form-group">
                <label for="due_date">Due Date</label>

                <input type="text" class="form-control col-md-4" name="due_date" id="due_date" value="{{ $task->due_date }}">
                @if ($errors->has('due_date'))
                    <span id="terms-error" class="error invalid-feedback" style="display: inline;">{{ $errors->first('due_date') }}</span>
                @endif
            </div>

            <div class="form-group">
                <label for="status">Status</label>
                <select class="form-control  col-md-4" id="status" name="status">
                    <option value="">Select</option>
                    <option value="In-Complete"  {{ $task->status=='In-Complete' ? 'selected' : '' }}>In-Completed</option>
                    <option value="Completed"  {{ $task->status=='Completed' ? 'selected' : '' }}>Completed</option>
                </select>
                @if ($errors->has('status'))
                    <span id="terms-error" class="error invalid-feedback" style="display: inline;">{{ $errors->first('status') }}</span>
                @endif
            </div>
            <div class="form-group mt-5">
                <a href="{{ route('task')}}" class="btn btn-light float-left">Cancel</a>
                <button type="submit"  class="btn btn-primary float-right">Update</button>
            </div>
        </form>
    </div>
    <script type="text/javascript">

        $( function() {
            $( "#due_date" ).datepicker({
                changeMonth: true,
                changeYear: true,
                showButtonPanel: true,
                minDate: new Date(),
            });
        });

        $(document).ready(function() {
        $("#frmEditTask").validate({
            errorElement: 'span',
            rules: {
                title: {
                    required: true,
                    minlength: 3
                },
                description: {
                    required: true
                },
                due_date: {
                    required: true
                },
                status: {
                    required: true
                },
            },
            messages: {

                title: {
                    required: "Please enter task title",
                    minlength: 'Minimum 3 characters'
                },
                description: {
                    required: "Please enter description",
                },
                due_date: {
                    required: "Please select due date",
                },
                status: {
                    required: "Please select status",
                },
            }
        });
    });
</script>
@endsection
