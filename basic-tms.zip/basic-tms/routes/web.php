<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TasksController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('task', [TasksController::class, 'index'])->name('task');
Route::get('task/list', [TasksController::class, 'getTaskList'])->name('task.list');

Route::get('task/add', [TasksController::class, 'add'])->name('task.add');
Route::post('task/save', [TasksController::class, 'save'])->name('task.save');

Route::get('task/edit/{id}', [TasksController::class, 'edit'])->name('task.edit');
Route::put('task/update/{id}', [TasksController::class, 'update'])->name('task.update');

Route::get('task/view/{id}', [TasksController::class, 'view'])->name('task.view');

Route::get('task/delete/{id}', [TasksController::class, 'destroy'])->name('task.delete');

Route::get('task/changestatus/{id}', [TasksController::class, 'changestatus'])->name('task.changestatus');
