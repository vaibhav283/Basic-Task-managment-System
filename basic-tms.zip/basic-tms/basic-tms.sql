-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2023 at 07:32 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `basic-tms`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_12_01_081255_create_tasks_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` enum('In-Complete','Completed') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `title`, `description`, `due_date`, `status`, `created_at`, `updated_at`) VALUES
(3, 'Aperiam voluptatibus quia modi incidunt odio.', 'Suscipit cumque iure ullam occaecati. Earum est consequatur voluptatem enim ducimus voluptas. Eum eligendi blanditiis velit incidunt rerum cupiditate.', '2023-12-03', 'In-Complete', '2023-12-01 04:43:25', '2023-12-01 12:46:01'),
(4, 'Est in beatae aut quos sed autem voluptatibus.', 'Voluptatem eligendi beatae voluptas aut earum. Et voluptatibus sint dolorem fugit harum impedit.', '2023-12-12', 'Completed', '2023-12-01 04:43:25', '2023-12-01 12:46:18'),
(5, 'A qui nam enim ut praesentium.', 'Commodi nam nobis et. Rem sint et non delectus. Dicta pariatur ad enim rerum odit deserunt saepe.', '2023-12-30', 'In-Complete', '2023-12-01 04:43:25', NULL),
(6, 'Quas hic eligendi ullam sequi sed.', 'Ducimus praesentium laborum sit. Quia est laborum distinctio ea est et. Optio non officia dignissimos autem numquam repellat.', '2023-12-09', 'Completed', '2023-12-01 04:43:25', '2023-12-01 12:46:09'),
(7, 'Aut ut numquam assumenda ad ut iure est.', 'Expedita nemo dolores sit similique molestiae. Dolor incidunt est tempore dignissimos minima error. Atque facilis enim nostrum illum.', '2023-12-20', 'In-Complete', '2023-12-01 04:43:25', NULL),
(8, 'Adipisci vitae et magnam unde.', 'Sint sed dolor omnis. Suscipit et nisi exercitationem nesciunt quidem aperiam architecto molestiae.', '2023-12-29', 'In-Complete', '2023-12-01 04:43:25', NULL),
(9, 'Iusto soluta aliquam aliquid.', 'Molestiae sint ea dolor sunt. Aut in dicta expedita incidunt.', '2023-12-25', 'In-Complete', '2023-12-01 04:43:25', NULL),
(10, 'Corporis optio vero similique et sequi voluptatem.', 'Soluta explicabo blanditiis recusandae. Quam vero incidunt aut illum non at. Et veritatis eum quos accusantium cupiditate sed ut.', '2023-12-06', 'In-Complete', '2023-12-01 04:43:25', NULL),
(11, 'Consequuntur porro ut quae et.', 'Similique qui similique totam enim. Magnam omnis eos quibusdam molestiae nulla excepturi. Corporis et eos repudiandae quis ut est eaque.', '2023-12-21', 'In-Complete', '2023-12-01 04:43:25', NULL),
(12, 'Expedita voluptas exercitationem sit.', 'Omnis perferendis laudantium enim tempora. Et non nihil architecto cupiditate minima. Assumenda dicta quod officiis minima vel.', '2023-12-20', 'In-Complete', '2023-12-01 04:43:25', NULL),
(13, 'Ipsam beatae vitae vero deleniti.', 'Aliquam qui ipsa et omnis. Molestiae a voluptatibus quod non odio architecto officia.', '2023-12-31', 'In-Complete', '2023-12-01 04:43:25', NULL),
(14, 'Autem recusandae voluptas totam iusto et.', 'Aliquam aut inventore incidunt illo alias odio repellendus nihil. Cumque corporis aut id numquam debitis. Ullam est iste ad est.', '2023-12-22', 'In-Complete', '2023-12-01 04:43:25', NULL),
(15, 'Optio autem est earum a.', 'Delectus fuga et dolorum cum. Et dolor tempora dolores cum voluptatibus est deleniti. Et culpa assumenda animi totam dolores cum debitis.', '2023-12-31', 'In-Complete', '2023-12-01 04:43:25', NULL),
(16, 'Autem in sit consectetur impedit.', 'Natus quia qui quia aut aut. Cumque id ut voluptate accusantium. Temporibus laudantium est blanditiis necessitatibus minus ut voluptas.', '2023-12-23', 'In-Complete', '2023-12-01 04:43:25', NULL),
(17, 'Voluptas totam tempore omnis accusamus.', 'Magni incidunt voluptatem totam enim. Ullam exercitationem voluptates ipsum sit nemo omnis. Deserunt commodi ipsam quod molestiae.', '2023-12-04', 'In-Complete', '2023-12-01 04:43:25', NULL),
(18, 'Doloremque quae aliquam provident fugiat aliquid veniam.', 'Enim modi officiis laudantium reprehenderit magni a nihil. Quis inventore error aut beatae maiores voluptatem voluptatem. Ea eligendi quo laudantium tempore ipsam hic esse.', '2023-12-24', 'In-Complete', '2023-12-01 04:43:25', NULL),
(19, 'Nihil quis vitae corporis.', 'Eum ut nesciunt sapiente sunt. Consequatur eveniet et itaque sapiente nam deserunt voluptatibus enim.', '2023-12-01', 'In-Complete', '2023-12-01 04:43:25', NULL),
(20, 'Nisi neque natus est nam neque tempora consectetur.', 'Ab sint in perspiciatis dolores corrupti. Deserunt nihil non odit. Quidem saepe laborum aliquid necessitatibus labore dolores nemo.', '2023-12-13', 'In-Complete', '2023-12-01 04:43:25', NULL),
(21, 'Test task', 'Please work on this test task', '2023-12-20', 'Completed', '2023-12-01 05:54:35', '2023-12-01 12:45:44'),
(22, 'Add new task list with delete feature', 'Add new task list with delete feature , make sure record must be deleted from system', '2023-12-27', 'In-Complete', '2023-12-01 07:42:24', '2023-12-01 07:42:24'),
(23, 'Create product listing', 'Create product listingCreate product listingCreate product listingCreate product listingCreate product listingCreate product listing', '2024-01-05', 'Completed', '2023-12-01 07:43:19', '2023-12-01 07:49:16'),
(24, 'HTML, CSS, and JavaScript framework', 'Bootstrap is the most popular HTML, CSS, and JavaScript framework for developing responsive, mobile-first websites. Bootstrap is the most popular HTML, CSS, and JavaScript framework for developing responsive, mobile-first websites. Bootstrap is the most popular HTML, CSS, and JavaScript framework for developing responsive, mobile-first websites. Bootstrap is the most popular HTML, CSS, and JavaScript framework for developing responsive, mobile-first websites.\r\nBootstrap is the most popular HTML, CSS, and JavaScript framework for developing responsive, mobile-first websites. Bootstrap is the most popular HTML, CSS, and JavaScript framework for developing responsive, mobile-first websites.\r\nBootstrap is the most popular HTML, CSS, and JavaScript framework for developing responsive, mobile-first websites. Bootstrap is the most popular HTML, CSS, and JavaScript framework for developing responsive, mobile-first websites.\r\nBootstrap is the most popular HTML, CSS, and JavaScript framework for developing responsive, mobile-first websites. Bootstrap is the most popular HTML, CSS, and JavaScript framework for developing responsive, mobile-first websites.\r\nBootstrap is the most popular HTML, CSS, and JavaScript framework for developing responsive, mobile-first websites. Bootstrap is the most popular HTML, CSS, and JavaScript framework for developing responsive, mobile-first websites.', '2023-12-20', 'In-Complete', '2023-12-01 09:56:01', '2023-12-01 09:56:50'),
(25, 'New testing task', 'New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task \r\n\r\n\r\nNew testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task New testing task', '2023-12-28', 'In-Complete', '2023-12-01 12:47:10', '2023-12-01 12:47:10'),
(26, 'Another task of data entry', 'Another task of data entry Another task of data entry Another task of data entry Another task of data entry Another task of data entry Another task of data entry Another task of data entry Another task of data entry Another task of data entry Another task of data entry', '2023-12-29', 'In-Complete', '2023-12-01 12:51:06', '2023-12-01 12:51:27');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
