<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task;
use DataTables;
use Exception;


class TasksController extends Controller
{
    public function index()
    {
        return view('tasks.list');
    }

    public function getTaskList(Request $request) {

        if($request->ajax()) {
            $data = Task::latest()->get();
            //dd($data);
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('due_date', function($data) {

                    return date('d F, Y', strtotime($data->due_date));
                })
                ->addColumn('created_at', function($data) {

                    return date('d F, Y H:i', strtotime($data->created_at));
                })
                ->addColumn('status', function($data) {
                    $status_class = ($data->status==='In-Complete') ? 'btn-danger' : 'btn-success';
                    $statusTag = '<a href="javacscript:void(0)" class="btn btn-sm '.$status_class.'" id="changeStatusBtn" data-id="'.$data->id.'">'.$data->status.' </a>';

                    //$statusTag = '<button type="button" class="btn btn-sm '.$status_class.'" data-toggle="modal" data-id="'.$data->id.'" data-target="#taskStatusChange" data-whatever="@mdo">'.$data->status.'</button>';

                    return $statusTag;
                })
                ->addColumn('action', function($data) {
                    $actionBtn = '<a href="javascript:void(0)" class="view btn btn-success btn-sm" id="viewBtn"  data-id="'.$data->id.'">View </a> &nbsp; | &nbsp; <a href="' . route('task.edit', $data->id) . '" class="edit btn btn-success btn-sm">Edit </a> &nbsp; | &nbsp; <a href="javascript:void(0)" class="delete btn btn-danger btn-sm deleteTask" id="delBtn" data-id="'.$data->id.'"> Delete </a>';
                    return $actionBtn;
                })
                ->rawColumns(['due_date', 'created_at','status', 'action'])
                ->make(true);
        }
    }


    public function add()
    {
        return view('tasks.add');
    }

    /**
     * Save a new record.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function save(Request $request)
    {
        // Validate input
        $request->validate([
            'title'             => 'required|min:3',
            'description'       => 'required',
            'due_date'          => 'required',
            'status'            => 'required',
        ],
        [
            'title.required'             => 'Please enter task title',
            'title.min'                  => 'Minimum 3 characters',
            'description.required'       => 'Please enter task description',
            'due_date.required'          => 'Please select due date',
            'status.required'            => 'Please select status',

        ]);

        try{
            // Convert the date format  m/d/y to Y-m-d
            $due_dt     = explode("/", $request->due_date);
            $due_date   = $due_dt[2]."-".$due_dt[0]."-".$due_dt[1];

            $task = new Task;
            $task->title          = $request->title;
            $task->description    = $request->description;
            $task->due_date       = $due_date;
            $task->status         = $request->status;
            $task->save();

            return redirect()->route('task')->with('success','Task added successfully.');
        }catch(Exception $e) {
            return redirect()->route('task.add')->with('error','Something went wrong, please try again');
        }
    }

    public function edit($id)
    {
        $task = Task::findOrFail($id);

        // Convert the date format Y-m-d to m/d/y
        $due_dt     = explode("-", $task->due_date);
        $due_date   = $due_dt[1]."/".$due_dt[2]."/".$due_dt[0];
        $task->due_date = $due_date;

        return view('tasks.edit', ['task' => $task]);
    }


    /**
     * Update the record.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // Validate input
        $request->validate([
            'title'             => 'required|min:3',
            'description'       => 'required',
            'due_date'          => 'required',
            'status'            => 'required',
        ],
        [
            'title.required'             => 'Please enter task title',
            'title.min'                  => 'Minimum 3 characters',
            'description.required'       => 'Please enter task description',
            'due_date.required'          => 'Please select due date',
            'status.required'            => 'Please select status',

        ]);

        try{
            $task = Task::find($id);
            $task->title            = $request->title;
            $task->description      = $request->description;
            $task->status           = $request->status;

            // Convert the date format  m/d/y to Y-m-d
            $due_dt     = explode("/", $request->due_date);
            $due_date   = $due_dt[2]."-".$due_dt[0]."-".$due_dt[1];
            $task->due_date = $due_date;

            $task->save();
            return redirect()->route('task')->with('success','Task updated successfully.');
        }catch(Exception $e) {
            return redirect()->route('task.edit')->with('error','Something went wrong, please try again');
        }
    }


     /**
     * Remove the record from db
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $task = Task::find($id);

        if ($task) {
            $task->delete();
            return response()->json(['message' => 'Task deleted successfully', 'success' => 1]);
        } else {
            return response()->json(['error' => 'Task not found', 'success' => 0], 404);
        }
    }

    /**
     * View the record from db
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function view($id)
    {
        $task = Task::findOrFail($id);

        $taskData['title'] = $task->title;
        $taskData['short_title'] = substr($task->title, 0, 50);
        $taskData['description'] = $task->description;
        $taskData['status'] = $task->status;
        $taskData['due_date'] = date('d F, Y', strtotime($task->due_date));
        $taskData['created_at'] = date('d F, Y H:i', strtotime($task->created_at));

        if ($task) {
            return response()->json(['data' => $taskData, 'success' => 1]);
        } else {
            return response()->json(['error' => 'task not found', 'success' => 0], 404);
        }
    }

    public function changestatus($id)
    {

        $task = Task::findOrFail($id);
        $status = $task->status=='In-Complete' ? 'Completed' : 'In-Complete';
        $data = ['status' => $status];
        $task->update($data);

        if ($task) {
            return response()->json(['msg' => 'Status changed successfully', 'success' => 1]);
        } else {
            return response()->json(['error' => 'Unable to change status', 'success' => 0], 404);
        }
        //return redirect()->route('your.route.name.index')->with('success', 'Record updated successfully');
    }

}
