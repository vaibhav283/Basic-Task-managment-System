<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3 class="mb-5">Task List
            <a href="<?php echo e(route('task')); ?>" class="btn btn-primary float-right">Back to task</a>
        </h3>

        <form action="<?php echo e(route('task.save')); ?>" method="POST" id="frmAddTask">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="title">Title</label>
                <input type="text" class="form-control" name="title" id="title" placeholder="Enter title">
                <?php if($errors->has('title')): ?>
                    <span id="terms-error" class="error invalid-feedback" style="display: inline;"><?php echo e($errors->first('title')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea class="form-control" name="description" id="description" rows="10"></textarea>
                <?php if($errors->has('description')): ?>
                    <span id="terms-error" class="error invalid-feedback" style="display: inline;"><?php echo e($errors->first('description')); ?></span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="due_date">Due Date</label>
                <input type="text" class="form-control col-md-4" name="due_date" id="due_date" >
                <?php if($errors->has('due_date')): ?>
                    <span id="terms-error" class="error invalid-feedback" style="display: inline;"><?php echo e($errors->first('due_date')); ?></span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="status">Status</label>
                <select class="form-control  col-md-4" id="status" name="status">
                    <option value="">Select</option>
                    <option value="In-Complete">In-Complete</option>
                    <option value="Completed">Completed</option>
                </select>
                <?php if($errors->has('status')): ?>
                    <span id="terms-error" class="error invalid-feedback" style="display: inline;"><?php echo e($errors->first('status')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group mt-2">
                <a href="<?php echo e(route('task')); ?>" class="btn btn-light float-left">Cancel</a>
                <button type="submit"  class="btn btn-primary float-right">Submit</button>
            </div>
        </form>
    </div>
    <script type="text/javascript">

        $( function() {
            $( "#due_date" ).datepicker({
                changeMonth: true,
                changeYear: true,
                showButtonPanel: true,
                minDate: new Date(),
            });
        });

        $(document).ready(function() {
        $("#frmAddTask").validate({
            errorElement: 'span',
            rules: {
                title: {
                    required: true,
                    minlength: 3
                },
                description: {
                    required: true
                },
                due_date: {
                    required: true
                },
                status: {
                    required: true
                },
            },
            messages: {

                title: {
                    required: "Please enter task title",
                    minlength: 'Minimum 3 characters'
                },
                description: {
                    required: "Please enter description",
                },
                due_date: {
                    required: "Please select due date",
                },
                status: {
                    required: "Please select status",
                },
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\xampp\htdocs\basic-tms\resources\views/tasks/add.blade.php ENDPATH**/ ?>