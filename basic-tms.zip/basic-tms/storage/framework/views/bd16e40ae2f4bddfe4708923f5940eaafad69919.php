<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3 class="mb-5">Task edit
            <a href="<?php echo e(route('task')); ?>" class="btn btn-primary float-right">Back to task</a>
        </h3>

        <form action="<?php echo e(route('task.update', ['id' => $task->id] )); ?>" method="POST" id="frmEditTask">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="title">Title</label>
                <input type="text" class="form-control" name="title" id="title" placeholder="Enter title" value="<?php echo e($task->title); ?>">
                <?php if($errors->has('title')): ?>
                    <span id="terms-error" class="error invalid-feedback" style="display: inline;"><?php echo e($errors->first('title')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea class="form-control" name="description" id="description" rows="10"><?php echo e($task->description); ?></textarea>
                <?php if($errors->has('description')): ?>
                    <span id="terms-error" class="error invalid-feedback" style="display: inline;"><?php echo e($errors->first('description')); ?></span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="due_date">Due Date</label>

                <input type="text" class="form-control col-md-4" name="due_date" id="due_date" value="<?php echo e($task->due_date); ?>">
                <?php if($errors->has('due_date')): ?>
                    <span id="terms-error" class="error invalid-feedback" style="display: inline;"><?php echo e($errors->first('due_date')); ?></span>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="status">Status</label>
                <select class="form-control  col-md-4" id="status" name="status">
                    <option value="">Select</option>
                    <option value="In-Complete"  <?php echo e($task->status=='In-Complete' ? 'selected' : ''); ?>>In-Completed</option>
                    <option value="Completed"  <?php echo e($task->status=='Completed' ? 'selected' : ''); ?>>Completed</option>
                </select>
                <?php if($errors->has('status')): ?>
                    <span id="terms-error" class="error invalid-feedback" style="display: inline;"><?php echo e($errors->first('status')); ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group mt-5">
                <a href="<?php echo e(route('task')); ?>" class="btn btn-light float-left">Cancel</a>
                <button type="submit"  class="btn btn-primary float-right">Update</button>
            </div>
        </form>
    </div>
    <script type="text/javascript">

        $( function() {
            $( "#due_date" ).datepicker({
                changeMonth: true,
                changeYear: true,
                showButtonPanel: true,
                minDate: new Date(),
            });
        });

        $(document).ready(function() {
        $("#frmEditTask").validate({
            errorElement: 'span',
            rules: {
                title: {
                    required: true,
                    minlength: 3
                },
                description: {
                    required: true
                },
                due_date: {
                    required: true
                },
                status: {
                    required: true
                },
            },
            messages: {

                title: {
                    required: "Please enter task title",
                    minlength: 'Minimum 3 characters'
                },
                description: {
                    required: "Please enter description",
                },
                due_date: {
                    required: "Please select due date",
                },
                status: {
                    required: "Please select status",
                },
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\xampp\htdocs\basic-tms\resources\views/tasks/edit.blade.php ENDPATH**/ ?>