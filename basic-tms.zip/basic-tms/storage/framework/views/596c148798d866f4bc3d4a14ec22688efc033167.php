<?php $__env->startSection('content'); ?>

<div class="container-fluid mt-5">
    <h3 class="mb-5">Task List
        <a href="<?php echo e(route('task.add')); ?>" class="btn btn-primary float-right">Add task</a>
    </h3>

    <?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <h5><i class="icon fas fa-check"></i> Success!</h5> <?php echo e(Session::get('success')); ?>

    </div>
    <?php endif; ?>

    <table class="table table-bordered task-datatable" id='task-datatable'>
        <thead>
            <tr>
                <th>No.</th>
                <th>Title</th>
                <th>Due Date</th>
                <th>Created Date</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
    </table>


    <!-- View Modal -->
    <div class="modal fade" id="viewTaskModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="taskShortTitle">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="title" class="col-form-label"><b>Title:</b></label>
                        <p id="taskTitle"></p>
                    </div>

                    <div class="form-group">
                        <label for="description" class="col-form-label"><b>Description:</b></label>
                        <p id="taskDescription"></p>
                    </div>

                    <div class="form-group">
                        <label for="due_date" class="col-form-label"><b>Due Date:</b></label>
                        <p id="taskDueDate"></p>
                    </div>

                    <div class="form-group">
                        <label for="created_date" class="col-form-label"><b>Created Date:</b></label>
                        <p id="taskCreatedDate"></p>
                    </div>

                    <div class="form-group">
                        <label for="status" class="col-form-label"><b>Status:</b></label>
                        <p id="taskStatus"></p>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

</div>
<script type="text/javascript">
    $(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            var table = $('.task-datatable').DataTable({
                processing:true,
                serverSide: true,
                ajax: "<?php echo e(route('task.list')); ?>",
                columns:[
                    { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
                    {data: 'title', name:'title'},
                    {data: 'due_date', name:'due_date'},
                    {data: 'created_at', name:'created_at'},
                    {
                        data:'status',
                        name:'status',
                        orderable:true,
                        searchable:true
                    },
                    {
                        data:'action',
                        name:'action',
                        orderable:true,
                        searchable:true
                    },
                ]
            })

            // Delete record
            $('#task-datatable').on('click','#delBtn',function() {

                var id = $(this).data('id');
                var deleteConfirm = confirm("Are you sure?");

                if (deleteConfirm == true) {
                    // AJAX request
                    $.ajax({
                        "url": "<?php echo e(url('task/delete')); ?>/"+id,
                        type: 'GET',
                        data: {_token: '<?php echo e(csrf_token()); ?>', id: id},
                        success: function(response){
                            if(response.success == 1){
                                alert("Record deleted.");
                                table.ajax.reload(); // Reload DataTable
                            }else{
                                alert("Invalid ID.");
                            }
                        }
                    });
                }
            });

            // Change status
            $('#task-datatable').on('click','#changeStatusBtn',function() {

                var id = $(this).data('id');
                var statusConfirm = confirm("Are you sure want change status?");

                if (statusConfirm == true) {
                    // AJAX request
                    $.ajax({
                        "url": "<?php echo e(url('task/changestatus')); ?>/"+id,
                        type: 'GET',
                        data: {_token: '<?php echo e(csrf_token()); ?>', id: id},
                        success: function(response){
                            if(response.success == 1){
                                alert("Task status changed successfully.");
                                table.ajax.reload(); // Reload DataTable
                            }else{
                                alert("Invalid ID.");
                            }
                        }
                    });
                }
            });

            // view record modal
            $('#task-datatable').on('click', '#viewBtn', function() {
                var id = $(this).data('id');
                // fetch data of task
                $.ajax({
                    "url": "<?php echo e(url('task/view')); ?>/"+id,
                    type: 'GET',
                    data: {_token: '<?php echo e(csrf_token()); ?>', id: id},
                    success: function(response){
                        if(response.success == 1){
                            $("#viewTaskModal").modal('show');
                            $("#taskTitle").text(response.data.title);
                            $("#taskShortTitle").text(response.data.short_title);
                            $("#taskDescription").text(response.data.description);
                            $("#taskDueDate").text(response.data.due_date);
                            $("#taskCreatedDate").text(response.data.created_at);
                            $("#taskStatus").text(response.data.status);
                        }else{
                            alert("Invalid ID.");
                        }
                    }
                });
            });


        });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\xampp\htdocs\basic-tms\resources\views/tasks/list.blade.php ENDPATH**/ ?>