<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Faker\Factory as Faker;

class TaskTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        foreach(range(1, 20) as $index)
        {
            DB::table('tasks')->insert([
                'title' => $faker->sentence(),
                'description' => $faker->paragraph(2, true),
                'due_date' => $faker->dateTimeBetween('now', '+30 days')->format('Y-m-d'),
                'status' => 'In-Complete',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        }
    }
}
